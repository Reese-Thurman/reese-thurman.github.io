#ifndef BANK_CALCULATIONS_H
#define BANK_CALCULATIONS_H

#include <string>
using namespace std;

class BankCalculations { // Declare class and functions
public:
    void calculateBalanceWithMonthlyDeposit(double t_initialInvestment, double t_monthlyDeposit, double t_interestRate, int t_numberOfYears);
    void calculateBalanceWithoutMonthlyDeposit(double t_initialInvestment, double t_interestRate, int t_numberOfYears);
    void displayMainScreen();
    void printDetails(int t_year, double t_yearEndBalance, double t_interestEarned);
};

#endif
