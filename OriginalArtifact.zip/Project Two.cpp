// Project Two.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <iostream>
#include <string>
#include "BankCalculations.h"

using namespace std;


int main()
{ 
	BankCalculations interestCalculation1;
	interestCalculation1.displayMainScreen(); // Display the main program screen to the user
	
}


