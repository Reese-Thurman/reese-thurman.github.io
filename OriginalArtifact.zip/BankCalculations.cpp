#include <iostream>
#include <string>
#include <iomanip>
#include "BankCalculations.h"
using namespace std;

// Displays the main program screen
void BankCalculations::displayMainScreen() {
    double initialInvestment = 0;
    double monthlyDeposit = 0;
    double annualInterest = 0;
    int years = 0;
    cout << "Welcome to Airgead Banking!" << endl << endl;
    cout << "********************************************************************************" << endl;
    cout << "*******************************Data Input***************************************" << endl;
    cout << "Initial Investment Amount: "; // Get data input from user
    cin >> initialInvestment;
    cout << "Monthly Deposit: ";
    cin >> monthlyDeposit;
    cout << "Annual Interest: ";
    cin >> annualInterest;
    cout << "Number of Years: ";
    cin >> years;

    if ((monthlyDeposit < 0) || (annualInterest < 0) || (years < 1)) {
        cout << "User Input Error!";
    }

    else {


        cout << endl; // Display title bar
        cout << "              Balance and Interest Without Additional Monthly Deposits" << endl;
        cout << "===================================================================================" << endl;
        cout << " Year                  Year End Balance                  Year End Earned Interest" << endl;
        cout << "-----------------------------------------------------------------------------------" << endl;
        calculateBalanceWithoutMonthlyDeposit(initialInvestment, annualInterest, years);

        cout << endl; // Display title bar
        cout << "               Balance and Interest With Additional Monthly Deposits" << endl;
        cout << "===================================================================================" << endl;
        cout << " Year                  Year End Balance                  Year End Earned Interest" << endl;
        cout << "-----------------------------------------------------------------------------------" << endl;
        calculateBalanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, annualInterest, years);

    }


}

/**
 * Calculates end of year balance for given number of years
 *
 * @param initialInvestment dollar amount of initial investment
 * @param interestRate percentage of investment earned each year (annually), so a passed value of 3.5 is a rate of .035
 * @param numberOfYears number of years to calculate balance for
 *
 * 
 */
void BankCalculations::calculateBalanceWithoutMonthlyDeposit(double t_initialInvestment, double t_interestRate, int t_numberOfYears) {

    double totalAmount = 0; // Declare and initialize variables
    double interestEarned = 0;
    double totalInterest = 0;
    int iYears = 1;

    totalAmount = t_initialInvestment;

    while (iYears < (t_numberOfYears + 1)) { // Calculate interest

        for (int i2 = 0; i2 < 12; i2++) {
            interestEarned = (totalAmount) * ((t_interestRate / 100.0) / 12.0);
            totalInterest = totalInterest + interestEarned;
            totalAmount = totalAmount + interestEarned;
        }

        printDetails(iYears, totalAmount, totalInterest);
        totalInterest = 0;
        iYears = iYears + 1;
    }
    
}

/**
 * Calculates end of year balance for a given number of years
 *
 * @param initialInvestment dollar amount of initial investment
 * @param monthlyDeposit dollar amount added into the investment each month
 * @param interestRate percentage of investment earned each year (annually), so a passed value of 3.5 is a rate of .035
 * @param numberOfYears number of years to calculate balance for
 *
 * 
 */
void BankCalculations::calculateBalanceWithMonthlyDeposit(double t_initialInvestment, double t_monthlyDeposit, double t_interestRate, int t_numberOfYears) {

    double totalAmount = 0; // Declare and initialize variables
    double interestEarned = 0;
    double totalInterest = 0;
    int iYears = 1;

    totalAmount = t_initialInvestment;

    while (iYears < (t_numberOfYears + 1)) { // Calculat interest

        for (int i2 = 0; i2 < 12; i2++) {
            interestEarned = (totalAmount + t_monthlyDeposit) * ((t_interestRate / 100.0) / 12.0);
            totalInterest = totalInterest + interestEarned;
            totalAmount = totalAmount + t_monthlyDeposit + interestEarned;
        }

        printDetails(iYears, totalAmount, totalInterest);
        iYears = iYears + 1;
        totalInterest = 0;

    }

    
}

/**
* Prints the calculated results of each years investment details in 3 separate fields
* @param year year number
* @param yearEndBalance the current dollar value of the investment
* @param interestEarned dollar amount of how much earned in that year
*/
void BankCalculations::printDetails(int t_year, double t_yearEndBalance, double t_interestEarned) {

   // Print annual interest and balance to user
    cout << fixed << setprecision(2) << " " << t_year << right << setw(25) << "$" << left << setw(10) << round(t_yearEndBalance * 100) / 100
        << right << setw(25) << "$" << left << setw(10) << round(t_interestEarned * 100) / 100 << endl;


}