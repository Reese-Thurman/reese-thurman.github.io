# main.py

"""
============================================================
Banking Game - Personal Finance Simulation
============================================================

Author: Reese Thurman
Course: CS 499 - Capstone Project
File: main.py

Description:
------------
This program is a text-based financial simulation game where the player
manages investments and savings with the goal of retiring as a millionaire
by the age of 65.

The game begins with a set initial investment, monthly deposit, and interest
rate. Each year, the balance grows through compound interest and deposits.
Random financial events (e.g., bonuses, inheritances, medical bills,
market crashes) introduce decision-making, where the player must choose
between investing or saving their money. These decisions impact the balance
positively or negatively.

The program uses constants to manage configurable settings (starting
balance, monthly deposit, retirement age, random events, etc.), making it
easy to adjust difficulty, balance outcomes, or expand gameplay.

Major Features:
---------------
- Compound interest calculations
- Annual summaries of balance and earned interest
- Random financial events with investment/saving decisions
- Win condition: reach $1,000,000 before retirement
- Post-Game Financial Analysis
- Menu system with options for:
  • Start Game
  • Game Settings
  • About Game
  • How to Play
  • Leaderboard

============================================================
"""


import time
import random
import winsound
from statistics import mean
import sqlite3
from datetime import datetime

# ============================
# Constants
# ============================

STARTING_AGE = 18
RETIREMENT_AGE = 65
YEARS_TO_PLAY = RETIREMENT_AGE - STARTING_AGE

STARTING_BALANCE = 5000.00
MONTHLY_DEPOSIT = 250.00
ANNUAL_INTEREST = 7.00

WIN_CONDITION = 1000000  # $1,000,000

BEEP_FREQUENCY_WIN = 1000
BEEP_FREQUENCY_LOSE = 250
BEEP_DURATION = 500  # milliseconds

HEADER_WIDTH = 80

WIN_MESSAGE = "Congratulations! You retired at age 65 with One Million Dollars!"
LOSE_MESSAGE = "You retired at age 65 with less than One Million Dollars. You Lose!"

EVENTS = [
    {
        "desc": "You received a work bonus of $2000! Do you want to invest it in the stock market?",
        "invest_gain": 4000,  # doubles if lucky
        "save_gain": 2000  # safe option
    },
    {
        "desc": "A friend invites you to join a startup. Risky! Invest?",
        "invest_gain": 5000,  # big reward
        "save_gain": 0  # no change
    },
    {
        "desc": "Unexpected medical bill of $1500. Do you want to pay with savings or invest in an insurance plan?",
        "invest_gain": -500,  # small loss with insurance
        "save_gain": -1500  # big loss
    },
    {
        "desc": "You inherited $3000! Do you invest it?",
        "invest_gain": 4500,
        "save_gain": 3000
    },
    {
        "desc": "Stock market crash! Do you hold your investments or pull out and place earnings into savings?",
        "invest_gain": -3000,  # big loss
        "save_gain": -1000
    }
]

DB_NAME = "banking_game.db"

# ============================
# Data Structures
# ============================

class YearRecord:
    def __init__(self, year, start_balance, end_balance, interest, event_desc=None, event_effect=0):
        self.year = year
        self.start_balance = start_balance
        self.end_balance = end_balance
        self.interest = interest
        self.event_desc = event_desc
        self.event_effect = event_effect

    def __repr__(self):
        return (f"Year {self.year}: Start={self.start_balance:.2f}, "
                f"End={self.end_balance:.2f}, Interest={self.interest:.2f}, "
                f"EventEffect={self.event_effect:+.2f}")

# ============================
# Database Setup
# ============================
def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # Create leaderboard table
    cursor.execute('''CREATE TABLE IF NOT EXISTS leaderboard (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        player_name TEXT NOT NULL,
                        score REAL NOT NULL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )''')

    # Create settings table
    cursor.execute('''CREATE TABLE IF NOT EXISTS settings (
                        id INTEGER PRIMARY KEY CHECK (id = 1),
                        difficulty TEXT NOT NULL
                    )''')

    # Insert default game settings none exists. Easy is the diffault setting
    cursor.execute("INSERT OR IGNORE INTO settings (id, difficulty) VALUES (1, 'easy')")
    conn.commit()
    conn.close()

# ============================
# Game Functions
# ============================

# Prints the calculated results of each year's investment details
def print_details(year, year_end_balance, interest_earned):
    # Prints the investment details for a given year.
    print(f"{year:<6} {year_end_balance:>20.2f} {interest_earned:>30.2f}")

# Calculates end of year balance for given number of years and compound interest with monthly deposits
def calculate_balance_with_monthly_deposit(initial_investment, monthly_deposit, interest_rate, number_of_years):

    total_amount = initial_investment
    years = 1
    history = []

    # Calculate balance with monthly deposits and set interest rate.
    while years <= number_of_years:
        start_of_year_balance = total_amount
        event_effect = 0
        event_desc = None
        random_integer = random.randint(1, 4)
        total_interest = 0

        # Calculate compound interest
        for _ in range(12):  # 12 months
            interest_earned = (total_amount + monthly_deposit) * ((interest_rate / 100.0) / 12.0)
            total_interest += interest_earned
            total_amount += monthly_deposit + interest_earned

        print_details(years, total_amount, total_interest)
        years += 1
        time.sleep(1)

        # Determine if a random event will appear
        if random_integer == 4:
            adjustment, desc = random_event()
            event_desc = desc
            event_effect = adjustment
            total_amount += adjustment
            print(f"{'Year':<6} {'Year End Balance':>20} {'Year End Earned Interest':>30}")

        history.append(YearRecord(years, start_of_year_balance, total_amount, total_interest, event_desc, event_effect))

    # Determine whether player has won the game based on retirement savings
    if total_amount >= WIN_CONDITION:
        frequency = 1000  # Set Frequency To 2500 Hertz
        duration = 500  # Set Duration To 1000 ms
        winsound.Beep(BEEP_FREQUENCY_WIN, BEEP_DURATION)
        winsound.Beep(BEEP_FREQUENCY_WIN, BEEP_DURATION)
        print(f"\n{WIN_MESSAGE}")
        time.sleep(1)
    else:
        frequency = 250  # Set Frequency To 2500 Hertz
        duration = 500  # Set Duration To 1000 ms
        winsound.Beep(BEEP_FREQUENCY_LOSE, BEEP_DURATION)
        winsound.Beep(BEEP_FREQUENCY_LOSE, BEEP_DURATION)
        print(f"\n{LOSE_MESSAGE}")
        time.sleep(1)

    analyze_trends(history)

    # Save player score to the leaderboard
    player_name = input("\nEnter your name for the leaderboard: ").strip()

    while not player_name:
        player_name = input("\nInvalid player name. Enter your name for the leaderboard: ").strip()

    save_score(player_name, total_amount)


# Generates a random financial event that influences the player's financial state
def random_event():
    # Simulates a random financial event. Returns a modifier for the balance.

    # Pick one event
    event = random.choice(EVENTS)

    print("\nRandom Event!")
    print(event["desc"])
    print(" [I] Invest")
    print(" [S] Save/Do Nothing")

    # Player will choose to invest or save when prompted with a random event.
    while True:
        choice = input("Your choice: ").strip().upper()

        if choice == "I":
            print()
            print(f"You chose to invest. Result: {event['invest_gain']} added to your balance.")
            return event["invest_gain"], event["desc"]
        elif choice == "S":
            print()
            print(f"You chose to save. Result: {event['save_gain']} added to your balance.")
            return event["save_gain"], event["desc"]
        else:
            print("\nInvalid choice, please try again.")

# This method analyzes and prints the player's financial trends after the game ends
def analyze_trends(history):

    print("\n=== Post-Game Financial Analysis ===")

    # Calculate average interest, average savings growth, and total risky player moves
    avg_interest = mean([x.interest for x in history])
    avg_savings_growth = mean([x.end_balance - x.start_balance for x in history])
    risky_years = sum(1 for x in history if x.event_effect < 0)

    print(f"Average yearly interest earned: ${avg_interest:,.2f}")
    print(f"Average yearly savings growth: ${avg_savings_growth:,.2f}")
    print(f"Number of risky/negative event years: {risky_years}")

    # Provide financial feedback to the player
    if risky_years > len(history) * 0.3:
        print("You experienced many risky setbacks. Consider safer choices.")
    elif avg_savings_growth > 10000:
        print("Great job! Your savings growth was strong year-over-year.")
    else:
        print("Steady progress, but there’s room to optimize your decisions.")

    input("\nPress ENTER to Continue ")

# Game start sequence. This function will also load game settings when a database is implemented in Module Five
def start_game():
    print("\nStarting the game")
    frequency = 500  # Set Frequency To 2500 Hertz
    duration = 500  # Set Duration To 1000 ms == 1 second
    winsound.Beep(frequency, duration)
    time.sleep(1)

    # Load game difficulty setting
    difficulty = get_settings()
    print(f"Loaded Game Difficulty Setting: {difficulty.upper()}")
    time.sleep(2)

    # Set game difficulty
    if difficulty == "easy":
        initial_investment, monthly_deposit, annual_interest = 5000, 250, 7
    elif difficulty == "moderate":
        initial_investment, monthly_deposit, annual_interest = 3000, 200, 6
    else:  # hard
        initial_investment, monthly_deposit, annual_interest = 1000, 100, 5

    # Print game settings
    print(f"\nInitial Investment Amount: ${initial_investment:,}")
    print(f"Monthly Deposit: ${monthly_deposit}")
    print(f"Annual Interest(%): {annual_interest}%")

    print("Starting Age: 18")

    print("Age of Retirement: 65")
    years = YEARS_TO_PLAY

    print(f"{'Years Until Retirement: '} {YEARS_TO_PLAY}")

    input("\nPress ENTER to Begin ")

    play_banking_game(initial_investment, monthly_deposit, annual_interest, years)

# This function begins the game by printing the game header.
def play_banking_game(initial_investment, monthly_deposit, annual_interest, years):

    # Print game header
    print("\nBalance and Interest With Monthly Deposits")
    print("=" * 80)
    print(f"{'Year':<6} {'Year End Balance':>20} {'Year End Earned Interest':>30}")
    print("-" * 80)
    calculate_balance_with_monthly_deposit(initial_investment, monthly_deposit, annual_interest, years)

# This function saves the player's score to the database
def save_score(player_name, score):

    # Do not save the score if the player name is invalid
    if not player_name.strip():
        print("Invalid name. Score not saved.")
        return

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO leaderboard (player_name, score) VALUES (?, ?)", (player_name, score))
    conn.commit()
    conn.close()

# This function retrieves the game difficulty setting from the database.
def get_settings():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT difficulty FROM settings WHERE id = 1")
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else "easy" # Easy is always the default game setting

# This function updates the game difficulty setting in the database.
def update_settings(new_difficulty):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE settings SET difficulty = ? WHERE id = 1", (new_difficulty,))
    conn.commit()
    conn.close()

# This function allows the player to select the game difficulty setting, which is saved to a database.
def game_settings():

    print("\n=== Game Settings ===")
    current = get_settings()
    print(f"Current difficulty: {current}")

    # Update game setting with input validation loop
    while True:
        choice = input("Choose difficulty (easy, moderate, hard): ").lower().strip()

        if choice in ["easy", "moderate", "hard"]:
            update_settings(choice)
            print(f"Difficulty updated to {choice}.")
            break  # exit loop once valid input is given
        else:
            print("Invalid choice. Please enter 'easy', 'moderate', or 'hard'.")

    time.sleep(1)

# This function describes the author and purpose of the game to the player
def about_game():
    print("\nAbout the Game")
    print("The Banking Game was developed by Reese Thurman for CS 499 - Capstone Project.")
    print("Your goal is to reach $1,000,000 by the age of 65.")
    print("Each year, you’ll face interest growth, deposits, and random life events!")
    print("Make smart decisions to build wealth and avoid setbacks!\n")

# This function gives game instructions to the player
def how_to_play():
    print("\nHow to Play")
    print("- Start the game at age 18 with an initial savings balance.")
    print("- Each turn represents one year of life.")
    print("- Earn interest, make deposits, and face random events.")
    print("- Reach $1,000,000 before age 65 to win!\n")

# This function retrieves the top game scores from the database
def get_leaderboard():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT player_name, score, timestamp FROM leaderboard ORDER BY score DESC LIMIT 10")
    rows = cursor.fetchall()
    conn.close()
    return rows

# This prints the scoreboard from the database.
def leaderboard():
    print("\n=== Leaderboard ===")
    scores = get_leaderboard()

    #Print the top scores if any exist
    if not scores:
        print("No scores yet! Play a game first.")
    else:
        for i, (name, score, timestamp) in enumerate(scores, start=1):
            print(f"{i}. {name} - ${score:,.2f} ({timestamp})")

    input("\nPress ENTER to return to menu...")

# Displays the main game menu
def display_game_menu():
    print("\n" + "=" * 70)
    print(" " * 20 + "💰 Welcome to the Banking Game! 💰")
    print("=" * 70)
    print("                               Main Menu")
    print("-" * 70)
    print("[S] Start Game")
    print("[G] Game Settings")
    print("[A] About Game")
    print("[H] How to Play")
    print("[L] Leaderboard")
    print("[Q] Quit Game")
    print("-" * 70)

    choice = input("Enter your selection: ").strip().upper()
    return choice

# The one and only main
def main():

    init_db()  # Initialize database if it doesnt already exist

    while True: # Loop through the game menu until the player chooses to exit
        choice = display_game_menu()

        if choice == "S":
            start_game()
        elif choice == "G":
            game_settings()
        elif choice == "A":
            about_game()
        elif choice == "H":
            how_to_play()
        elif choice == "L":
            leaderboard()
        elif choice == "Q":
            print("\nThanks for playing the Banking Game! Goodbye!\n")
            break
        else:
            print("\nInvalid choice, please try again.")

if __name__ == "__main__":
    main()
